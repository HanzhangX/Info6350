package com.mycompany.info6350

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
