import 'package:flutter/material.dart';
import 'backend/backend.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:csv/csv.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static final FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal() {
    initializePersistedState();
  }

  Future initializePersistedState() async {
    secureStorage = FlutterSecureStorage();
    _PhotoList =
        await secureStorage.getStringList('ff_PhotoList') ?? _PhotoList;
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late FlutterSecureStorage secureStorage;

  List<String> _PhotoList = [];
  List<String> get PhotoList => _PhotoList;
  set PhotoList(List<String> _value) {
    _PhotoList = _value;
    secureStorage.setStringList('ff_PhotoList', _value);
  }

  void deletePhotoList() {
    secureStorage.delete(key: 'ff_PhotoList');
  }

  void addToPhotoList(String _value) {
    _PhotoList.add(_value);
    secureStorage.setStringList('ff_PhotoList', _PhotoList);
  }

  void removeFromPhotoList(String _value) {
    _PhotoList.remove(_value);
    secureStorage.setStringList('ff_PhotoList', _PhotoList);
  }

  void removeAtIndexFromPhotoList(int _index) {
    _PhotoList.removeAt(_index);
    secureStorage.setStringList('ff_PhotoList', _PhotoList);
  }

  List<String> _listlist = [];
  List<String> get listlist => _listlist;
  set listlist(List<String> _value) {
    _listlist = _value;
  }

  void addToListlist(String _value) {
    _listlist.add(_value);
  }

  void removeFromListlist(String _value) {
    _listlist.remove(_value);
  }

  void removeAtIndexFromListlist(int _index) {
    _listlist.removeAt(_index);
  }
}

LatLng? _latLngFromString(String? val) {
  if (val == null) {
    return null;
  }
  final split = val.split(',');
  final lat = double.parse(split.first);
  final lng = double.parse(split.last);
  return LatLng(lat, lng);
}

extension FlutterSecureStorageExtensions on FlutterSecureStorage {
  void remove(String key) => delete(key: key);

  Future<String?> getString(String key) async => await read(key: key);
  Future<void> setString(String key, String value) async =>
      await write(key: key, value: value);

  Future<bool?> getBool(String key) async => (await read(key: key)) == 'true';
  Future<void> setBool(String key, bool value) async =>
      await write(key: key, value: value.toString());

  Future<int?> getInt(String key) async =>
      int.tryParse(await read(key: key) ?? '');
  Future<void> setInt(String key, int value) async =>
      await write(key: key, value: value.toString());

  Future<double?> getDouble(String key) async =>
      double.tryParse(await read(key: key) ?? '');
  Future<void> setDouble(String key, double value) async =>
      await write(key: key, value: value.toString());

  Future<List<String>?> getStringList(String key) async =>
      await read(key: key).then((result) {
        if (result == null || result.isEmpty) {
          return null;
        }
        return CsvToListConverter()
            .convert(result)
            .first
            .map((e) => e.toString())
            .toList();
      });
  Future<void> setStringList(String key, List<String> value) async =>
      await write(key: key, value: ListToCsvConverter().convert([value]));
}
