import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyBZQ47P1wBQXfOMD9ApeHrtSmZC41Bgcd8",
            authDomain: "info6350xhz.firebaseapp.com",
            projectId: "info6350xhz",
            storageBucket: "info6350xhz.appspot.com",
            messagingSenderId: "290541974375",
            appId: "1:290541974375:web:c6be1012360329d5c475c2"));
  } else {
    await Firebase.initializeApp();
  }
}
